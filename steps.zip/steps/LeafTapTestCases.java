package steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LeafTapTestCases extends BaseClass {

	//public ChromeDriver driver;
	public static String leadID;
	public static String text;
	public static Set<String> allWindows;
	public static Set<String> allWindows2;
	public static List<String> allhandles;
	public static List<String> allhandles2;
	public static String leadID1;

	/*
	 * @Given("Open Chrome browser") public void openBrowser() {
	 * WebDriverManager.chromedriver().setup(); driver=new ChromeDriver();
	 * driver.manage().window().maximize(); }
	 * 
	 * @Given("Load application URL") public void loadApplicationURL() {
	 * driver.get("http://leaftaps.com/opentaps/control/main"); }
	 */
	@And("Enter Username as {string}")
	public void enterUserName(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
	}
	@And("Enter Password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	
	@When("Click on Login button")
	public void clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	@Then("LeafTap Welcome page should be displayed")
	public void verifyWelcomePage() {
		boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
		Assert.assertTrue(displayed);
	}
	
	
	@When("Click on CRM\\/SFA icon")
	public void click_on_crm_sfa_icon() {
		driver.findElement(By.linkText("CRM/SFA")).click();
	    //throw new io.cucumber.java.PendingException();
	}
	
	@Then("Home page should be displayed")
	public void verifyHomePage() {
		boolean displayed = driver.findElement(By.linkText("My Home")).isDisplayed();
		Assert.assertTrue(displayed);
	}
	
	@Then("Click on Lead button")
	public void verifyLeadButton() {
		driver.findElement(By.linkText("Leads")).click();
	}
	
	@Then("Click on Create Lead Button")
	public void clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
	}
	@Given("Enter the Company Name as {string}")
	public void enterCompanyName(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		
	}
	@Given("Enter the First Name as {string}")
	public void enterFirstName(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
	}
	@Given("Enter the Last Name as {string}")
	public void enterLastName(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	}
	@Given("Click on Submit button")
	public void clickSubmitButton() {
		driver.findElement(By.name("submitButton")).click();
	}
	
	@When("Click on Find Leads button")
	public void clickFindLeads() {
		driver.findElement(By.linkText("Find Leads")).click();
	}
	
	@Then("Click on Phone number button")
	public void clickPhoneNum() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
	}
	@Given("Enter phone number {string}")
	public void enterPhoneNum(String phNum) {
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phNum);
	}
	@When("Click on Find button")
	public void clickFindButton() {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
	}
	@Then("Store the first lead ID")
	public void storeFirstLeadID() {
		leadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
	}
	@Then("Click on First Lead")
	public void selectFirstLead() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
	}
	@Then("Click on Edit Button")
	public void clickEdit() {
		driver.findElement(By.linkText("Edit")).click();
	}
	@Given("Enter Company Name {string}")
	public void enterCompany1Name(String cName) {
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(cName);
	}
	@Given("Click on Submit Button")
	public void clickSubmit() {
		driver.findElement(By.name("submitButton")).click();
	}
	@Given("Click on Delete Button")
	public void clickDeletButton() {
		driver.findElement(By.linkText("Delete")).click();
	}
	
	@Given("Enter Lead ID")
	public void enterLeadID() {
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(leadID);
	}
	@Given("Enter Lead1 ID")
	public void enterLead1ID() {
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(leadID1);
	}
	@When("Get the Number of records")
	public void getNumOfRecords() {
		text = driver.findElement(By.className("x-paging-info")).getText();
	}
	@Then("If record found")
	public void displayRecordResult() {
		if (text.equals("No records to display")) {
			System.out.println("Text matched");
		} else {
			System.out.println("Text not matched");
		}
	}
	@Given("Close the driver")
	public void closeDeriver() {
		driver.close();
	}
	@Then("Click on Duplicate Button")
	public void clickDuplicateButton() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
	}
	@Then("Click on Merge Lead")
	public void clickOnMergeLead() {
		driver.findElement(By.linkText("Merge Leads")).click();
	}
	@Then("Click on From Lead Icon")
	public void clickFromLead() {
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
	}
	@Then("Flow to first window")
	public void windowHandles() {
		allWindows = driver.getWindowHandles();
		allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));
		
	}
	@Then("Get From Lead")
	public void getFromLead() throws InterruptedException {
		Thread.sleep(1000);
		leadID1 = driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]")).getText();
		driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]")).click();
		driver.switchTo().window(allhandles.get(0));
	}
	
	@Then("Click on To Lead Icon")
	public void clickToLead() throws InterruptedException {
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
		allWindows2 = driver.getWindowHandles();
		allhandles2 = new ArrayList<String>(allWindows2);
		driver.switchTo().window(allhandles2.get(1));
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[2]")).click();
	}
	@Then("Flow to second window")
	public void windowHandles1() {
		driver.switchTo().window(allhandles2.get(0));
	}
	@Then("Click on Merge")
	public void clickMerge() {
		driver.findElement(By.xpath("//a[text()='Merge']")).click();
	}
	@Then("Accept the alert")
	public void acceptAlert() {
		driver.switchTo().alert().accept();
		
	}
	
}
