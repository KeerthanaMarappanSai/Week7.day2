package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefinition extends BaseClass{
	
	//public static ChromeDriver driver;

	/*
	 * @Given("Open the Chrome browser") public void openBrowser() {
	 * WebDriverManager.chromedriver().setup(); driver=new ChromeDriver();
	 * driver.manage().window().maximize(); }
	 * 
	 * @Given("Load the application URL") public void loadApplicationURL() {
	 * driver.get("http://leaftaps.com/opentaps/control/main"); }
	 */
	@And("Enter the Username as {string}")
	public void enterUserName(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
	}
	@And("Enter the Password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	
	@When("Click on login button")
	public void clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	@Then("LeafTap home page should be displayed")
	public void VerifyJomePage() {
		boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
		if(displayed)
		{
			System.out.println("Home Page is displayed");
		}
		else
			System.out.println("Home Page is not displayed");
	}

	@But("Error message should be displayed")
	public void verifyErrorMessage() {
		boolean displayed = driver.findElement(By.id("errorDiv")).isDisplayed();
		if(displayed)
		{
			System.out.println("Error message is displayed");
		}
		else
			System.out.println("Error message is not displayed");
	}
	
}
