package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import steps.BaseClass;

@CucumberOptions(features={"src/test/java/feature/CreateLead.feature",
		"src/test/java/feature/EditLead.feature",
		"src/test/java/feature/DuplicateLead.feature",
		"src/test/java/feature/DeleteLead.feature",
		"src/test/java/feature/MergeLead.feature"},
		glue="steps", 
		monochrome=true,
		publish=true,
		tags="@functional or @regression"
		)
public class CreateLeadRunner extends BaseClass {

}
